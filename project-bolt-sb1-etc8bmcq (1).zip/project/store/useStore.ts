import { create } from 'zustand';
import { Flashcard, UserProgress } from '../types/flashcard';
import AsyncStorage from '@react-native-async-storage/async-storage';

interface AppState {
  flashcards: Flashcard[];
  currentCard: Flashcard | null;
  userProgress: UserProgress;
  setFlashcards: (cards: Flashcard[]) => void;
  updateCardProgress: (cardId: string, known: boolean) => void;
  updateUserProgress: (progress: Partial<UserProgress>) => void;
}

const initialUserProgress: UserProgress = {
  streak: 0,
  lastStudyDate: Date.now(),
  totalStudyTime: 0,
  cardsLearned: 0,
  cardsReviewed: 0,
};

export const useStore = create<AppState>((set, get) => ({
  flashcards: [],
  currentCard: null,
  userProgress: initialUserProgress,

  setFlashcards: (cards) => {
    set({ flashcards: cards });
    AsyncStorage.setItem('flashcards', JSON.stringify(cards));
  },

  updateCardProgress: (cardId, known) => {
    const { flashcards } = get();
    const updatedCards = flashcards.map((card) => {
      if (card.id === cardId) {
        const newSuccessRate = known
          ? (card.successRate * card.reviewCount + 1) / (card.reviewCount + 1)
          : (card.successRate * card.reviewCount) / (card.reviewCount + 1);
        
        return {
          ...card,
          successRate: newSuccessRate,
          reviewCount: card.reviewCount + 1,
          lastReviewed: Date.now(),
          nextReview: Date.now() + calculateNextReviewInterval(newSuccessRate),
        };
      }
      return card;
    });

    set({ flashcards: updatedCards });
    AsyncStorage.setItem('flashcards', JSON.stringify(updatedCards));
  },

  updateUserProgress: (progress) => {
    set((state) => ({
      userProgress: { ...state.userProgress, ...progress },
    }));
    AsyncStorage.setItem(
      'userProgress',
      JSON.stringify({ ...get().userProgress, ...progress })
    );
  },
}));

function calculateNextReviewInterval(successRate: number): number {
  // Base interval in milliseconds (1 day)
  const baseInterval = 24 * 60 * 60 * 1000;
  
  if (successRate < 0.3) return baseInterval * 0.5; // 12 hours
  if (successRate < 0.6) return baseInterval; // 1 day
  if (successRate < 0.8) return baseInterval * 3; // 3 days
  if (successRate < 0.9) return baseInterval * 7; // 1 week
  return baseInterval * 14; // 2 weeks
}