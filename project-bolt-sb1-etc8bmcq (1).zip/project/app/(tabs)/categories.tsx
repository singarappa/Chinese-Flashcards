import React from 'react';
import { StyleSheet, View, Text, Image, Pressable } from 'react-native';
import { FlashList } from '@shopify/flash-list';
import { useRouter } from 'expo-router';
import { initialFlashcards, CATEGORY_COLORS } from '../../data/flashcards';

const categories = [
  {
    id: 'basic',
    name: 'Basic Characters',
    description: 'Foundation Chinese characters',
    imageUrl: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=500&q=80',
    cardCount: initialFlashcards.filter(card => card.category === 'basic').length,
    difficulty: 1,
  },
  {
    id: 'numbers',
    name: 'Numbers & Position',
    description: 'Numbers and spatial concepts',
    imageUrl: 'https://images.unsplash.com/photo-1509228468518-180dd4864904?w=500&q=80',
    cardCount: initialFlashcards.filter(card => card.category === 'numbers').length,
    difficulty: 1,
  },
  {
    id: 'nature',
    name: 'Nature',
    description: 'Words about the natural world',
    imageUrl: 'https://images.unsplash.com/photo-1501854140801-50d01698950b?w=500&q=80',
    cardCount: initialFlashcards.filter(card => card.category === 'nature').length,
    difficulty: 2,
  },
  {
    id: 'people',
    name: 'People & Body',
    description: 'People and body parts',
    imageUrl: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=500&q=80',
    cardCount: initialFlashcards.filter(card => card.category === 'people').length,
    difficulty: 2,
  },
  {
    id: 'actions',
    name: 'Actions',
    description: 'Common verbs and actions',
    imageUrl: 'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=500&q=80',
    cardCount: initialFlashcards.filter(card => card.category === 'actions').length,
    difficulty: 2,
  },
  {
    id: 'phrases',
    name: 'Phrases',
    description: 'Useful everyday phrases',
    imageUrl: 'https://images.unsplash.com/photo-1516979187457-637abb4f9353?w=500&q=80',
    cardCount: initialFlashcards.filter(card => card.category === 'phrases').length,
    difficulty: 4,
  },
  {
    id: 'idioms',
    name: 'Idioms',
    description: 'Traditional Chinese idioms',
    imageUrl: 'https://images.unsplash.com/photo-1457369804613-52c61a468e7d?w=500&q=80',
    cardCount: initialFlashcards.filter(card => card.category === 'idioms').length,
    difficulty: 5,
  },
];

export default function CategoriesScreen() {
  const router = useRouter();

  const renderCategory = ({ item }: { item: typeof categories[0] }) => (
    <Pressable 
      style={styles.card}
      onPress={() => router.push(`/categories/${item.id}`)}
    >
      <Image
        source={{ uri: item.imageUrl }}
        style={styles.cardImage}
      />
      <View style={[styles.cardContent, { borderTopColor: CATEGORY_COLORS[item.id as keyof typeof CATEGORY_COLORS] }]}>
        <View style={styles.cardHeader}>
          <Text style={styles.cardTitle}>{item.name}</Text>
          <View style={styles.difficultyBadge}>
            <Text style={styles.difficultyText}>HSK {item.difficulty}</Text>
          </View>
        </View>
        <Text style={styles.cardDescription}>{item.description}</Text>
        <Text style={styles.cardCount}>{item.cardCount} words</Text>
      </View>
    </Pressable>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Categories</Text>
      <FlashList
        data={categories}
        renderItem={renderCategory}
        estimatedItemSize={200}
        contentContainerStyle={styles.list}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f6fa',
    paddingTop: 60,
  },
  header: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#333',
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  list: {
    padding: 20,
  },
  card: {
    backgroundColor: 'white',
    borderRadius: 15,
    marginBottom: 20,
    overflow: 'hidden',
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
  },
  cardImage: {
    width: '100%',
    height: 150,
  },
  cardContent: {
    padding: 15,
    borderTopWidth: 3,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  cardTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
  },
  difficultyBadge: {
    backgroundColor: '#4A90E2',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
  },
  difficultyText: {
    color: 'white',
    fontSize: 12,
    fontWeight: 'bold',
  },
  cardDescription: {
    color: '#666',
    marginBottom: 8,
  },
  cardCount: {
    color: '#999',
    fontSize: 12,
  },
});