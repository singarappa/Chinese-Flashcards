import React, { useState, useEffect } from 'react';
import { StyleSheet, View, Text } from 'react-native';
import { useStore } from '../../store/useStore';
import FlashCard from '../../components/FlashCard';
import { Ionicons } from '@expo/vector-icons';
import { initialFlashcards } from '../../data/flashcards';

export default function LearnScreen() {
  const { flashcards, setFlashcards, updateCardProgress, updateUserProgress } = useStore();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [sessionStartTime, setSessionStartTime] = useState(Date.now());

  useEffect(() => {
    if (flashcards.length === 0) {
      setFlashcards(initialFlashcards);
    }
  }, []);

  useEffect(() => {
    return () => {
      const studyTime = Date.now() - sessionStartTime;
      updateUserProgress({ totalStudyTime: studyTime });
    };
  }, []);

  const handleNext = () => {
    if (currentIndex < flashcards.length - 1) {
      setCurrentIndex(prev => prev + 1);
      setIsFlipped(false);
    }
  };

  const handlePrevious = () => {
    if (currentIndex > 0) {
      setCurrentIndex(prev => prev - 1);
      setIsFlipped(false);
    }
  };

  const handleSwipe = (direction: 'left' | 'right') => {
    const known = direction === 'right';
    updateCardProgress(flashcards[currentIndex].id, known);
    handleNext();
    updateUserProgress({
      cardsReviewed: currentIndex + 1,
      cardsLearned: known ? currentIndex + 1 : currentIndex,
    });
  };

  if (!flashcards.length) {
    return (
      <View style={styles.emptyContainer}>
        <Ionicons name="book-outline" size={64} color="#ccc" />
        <Text style={styles.emptyText}>Loading flashcards...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.progressContainer}>
        <Text style={styles.progressText}>
          Card {currentIndex + 1} of {flashcards.length}
        </Text>
      </View>

      <FlashCard
        card={flashcards[currentIndex]}
        onSwipe={handleSwipe}
        isFlipped={isFlipped}
        onFlip={() => setIsFlipped(!isFlipped)}
        onNext={handleNext}
        onPrevious={handlePrevious}
        isFirstCard={currentIndex === 0}
        isLastCard={currentIndex === flashcards.length - 1}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f6fa',
    paddingTop: 60,
  },
  progressContainer: {
    padding: 20,
    alignItems: 'center',
  },
  progressText: {
    fontSize: 16,
    color: '#666',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f5f6fa',
  },
  emptyText: {
    fontSize: 18,
    color: '#666',
    marginTop: 16,
  },
});