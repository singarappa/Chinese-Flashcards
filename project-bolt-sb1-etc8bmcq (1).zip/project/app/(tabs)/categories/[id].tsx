import React from 'react';
import { StyleSheet, View, Text, ScrollView, Pressable } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { initialFlashcards, CATEGORY_COLORS } from '../../../data/flashcards';

export default function CategoryDetailsScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  
  if (!id) {
    return (
      <View style={styles.container}>
        <View style={styles.header}>
          <Pressable 
            style={styles.backButton} 
            onPress={() => router.push('/categories')}
          >
            <Ionicons name="arrow-back" size={24} color="#333" />
          </Pressable>
          <Text style={styles.headerTitle}>Category Not Found</Text>
        </View>
      </View>
    );
  }

  const categoryFlashcards = initialFlashcards.filter(card => 
    card.category === id
  );

  const categoryName = id.charAt(0).toUpperCase() + id.slice(1);
  const categoryColor = CATEGORY_COLORS[id as keyof typeof CATEGORY_COLORS];

  return (
    <View style={styles.container}>
      <View style={[styles.header, { borderBottomColor: categoryColor }]}>
        <Pressable 
          style={styles.backButton} 
          onPress={() => router.push('/categories')}
        >
          <Ionicons name="arrow-back" size={24} color="#333" />
        </Pressable>
        <Text style={styles.headerTitle}>{categoryName}</Text>
      </View>

      <ScrollView 
        style={styles.cardList}
        contentContainerStyle={styles.cardListContent}
      >
        <View style={styles.statsContainer}>
          <View style={styles.statItem}>
            <Text style={styles.statNumber}>{categoryFlashcards.length}</Text>
            <Text style={styles.statLabel}>Words</Text>
          </View>
          <View style={styles.statItem}>
            <Text style={styles.statNumber}>
              {categoryFlashcards.filter(card => card.difficulty <= 3).length}
            </Text>
            <Text style={styles.statLabel}>Basic</Text>
          </View>
          <View style={styles.statItem}>
            <Text style={styles.statNumber}>
              {categoryFlashcards.filter(card => card.difficulty > 3).length}
            </Text>
            <Text style={styles.statLabel}>Advanced</Text>
          </View>
        </View>

        {categoryFlashcards.map((card) => (
          <View 
            key={card.id} 
            style={[
              styles.card,
              { borderLeftColor: categoryColor }
            ]}
          >
            <View style={styles.cardHeader}>
              <Text style={styles.character}>{card.character}</Text>
              <View style={styles.difficultyContainer}>
                {[...Array(card.difficulty)].map((_, i) => (
                  <Ionicons key={i} name="star" size={12} color="#FFD700" />
                ))}
              </View>
            </View>
            <Text style={styles.pinyin}>{card.pinyin}</Text>
            <Text style={styles.english}>{card.english}</Text>
            <View style={styles.example}>
              <Text style={styles.exampleChinese}>{card.example.chinese}</Text>
              <Text style={styles.examplePinyin}>{card.example.pinyin}</Text>
              <Text style={styles.exampleEnglish}>{card.example.english}</Text>
            </View>
          </View>
        ))}

        {categoryFlashcards.length === 0 && (
          <View style={styles.emptyState}>
            <Ionicons name="book-outline" size={64} color="#ccc" />
            <Text style={styles.emptyStateText}>No words found in this category</Text>
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f6fa',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 20,
    paddingTop: 60,
    backgroundColor: 'white',
    borderBottomWidth: 3,
  },
  backButton: {
    padding: 8,
    marginRight: 16,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    backgroundColor: 'white',
    padding: 20,
    marginBottom: 20,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  statItem: {
    alignItems: 'center',
  },
  statNumber: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
  },
  statLabel: {
    fontSize: 14,
    color: '#666',
    marginTop: 4,
  },
  cardList: {
    flex: 1,
  },
  cardListContent: {
    padding: 16,
  },
  card: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderLeftWidth: 4,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  character: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
  },
  difficultyContainer: {
    flexDirection: 'row',
    gap: 2,
  },
  pinyin: {
    fontSize: 16,
    color: '#4A90E2',
    marginBottom: 4,
  },
  english: {
    fontSize: 16,
    color: '#666',
    marginBottom: 12,
  },
  example: {
    backgroundColor: '#f8f9fa',
    padding: 12,
    borderRadius: 8,
  },
  exampleChinese: {
    fontSize: 16,
    color: '#333',
    marginBottom: 4,
  },
  examplePinyin: {
    fontSize: 14,
    color: '#666',
    marginBottom: 4,
  },
  exampleEnglish: {
    fontSize: 14,
    color: '#666',
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 40,
  },
  emptyStateText: {
    fontSize: 16,
    color: '#666',
    marginTop: 16,
    textAlign: 'center',
  },
});