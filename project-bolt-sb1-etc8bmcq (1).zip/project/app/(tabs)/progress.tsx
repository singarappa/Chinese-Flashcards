import React from 'react';
import { StyleSheet, View, Text, ScrollView } from 'react-native';
import { useStore } from '../../store/useStore';
import { Ionicons } from '@expo/vector-icons';

export default function ProgressScreen() {
  const { userProgress, flashcards } = useStore();

  const calculateMasteryLevel = () => {
    if (!flashcards.length) return 0;
    const totalSuccessRate = flashcards.reduce(
      (sum, card) => sum + card.successRate,
      0
    );
    return (totalSuccessRate / flashcards.length) * 100;
  };

  const formatStudyTime = (ms: number) => {
    const hours = Math.floor(ms / (1000 * 60 * 60));
    const minutes = Math.floor((ms % (1000 * 60 * 60)) / (1000 * 60));
    return `${hours}h ${minutes}m`;
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.header}>Your Progress</Text>

      <View style={styles.statsGrid}>
        <View style={styles.statCard}>
          <Ionicons name="flame-outline" size={32} color="#4A90E2" />
          <Text style={styles.statValue}>{userProgress.streak}</Text>
          <Text style={styles.statLabel}>Day Streak</Text>
        </View>

        <View style={styles.statCard}>
          <Ionicons name="time-outline" size={32} color="#4A90E2" />
          <Text style={styles.statValue}>
            {formatStudyTime(userProgress.totalStudyTime)}
          </Text>
          <Text style={styles.statLabel}>Study Time</Text>
        </View>

        <View style={styles.statCard}>
          <Ionicons name="checkmark-circle-outline" size={32} color="#4A90E2" />
          <Text style={styles.statValue}>{userProgress.cardsLearned}</Text>
          <Text style={styles.statLabel}>Cards Learned</Text>
        </View>

        <View style={styles.statCard}>
          <Ionicons name="refresh-outline" size={32} color="#4A90E2" />
          <Text style={styles.statValue}>{userProgress.cardsReviewed}</Text>
          <Text style={styles.statLabel}>Cards Reviewed</Text>
        </View>
      </View>

      <View style={styles.masteryCard}>
        <Text style={styles.masteryTitle}>Overall Mastery</Text>
        <View style={styles.masteryBarContainer}>
          <View
            style={[
              styles.masteryBar,
              { width: `${calculateMasteryLevel()}%` },
            ]}
          />
        </View>
        <Text style={styles.masteryPercent}>
          {calculateMasteryLevel().toFixed(1)}%
        </Text>
      </View>

      <View style={styles.achievementsSection}>
        <Text style={styles.sectionTitle}>Recent Achievements</Text>
        <View style={styles.achievement}>
          <Ionicons name="trophy-outline" size={24} color="#FFD700" />
          <View style={styles.achievementText}>
            <Text style={styles.achievementTitle}>First Steps</Text>
            <Text style={styles.achievementDesc}>
              Completed your first learning session
            </Text>
          </View>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f6fa',
    paddingTop: 60,
  },
  header: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#333',
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    padding: 10,
  },
  statCard: {
    width: '45%',
    backgroundColor: 'white',
    margin: '2.5%',
    padding: 15,
    borderRadius: 15,
    alignItems: 'center',
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
  },
  statValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    marginVertical: 8,
  },
  statLabel: {
    color: '#666',
    fontSize: 14,
  },
  masteryCard: {
    backgroundColor: 'white',
    margin: 20,
    padding: 20,
    borderRadius: 15,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
  },
  masteryTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 15,
  },
  masteryBarContainer: {
    height: 20,
    backgroundColor: '#f0f0f0',
    borderRadius: 10,
    overflow: 'hidden',
  },
  masteryBar: {
    height: '100%',
    backgroundColor: '#4A90E2',
    borderRadius: 10,
  },
  masteryPercent: {
    textAlign: 'center',
    marginTop: 10,
    color: '#666',
  },
  achievementsSection: {
    padding: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 15,
  },
  achievement: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'white',
    padding: 15,
    borderRadius: 10,
    marginBottom: 10,
  },
  achievementText: {
    marginLeft: 15,
  },
  achievementTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  achievementDesc: {
    color: '#666',
    fontSize: 14,
  },
});