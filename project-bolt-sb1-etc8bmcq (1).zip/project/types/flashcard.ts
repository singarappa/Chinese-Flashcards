export interface Flashcard {
  id: string;
  character: string;
  pinyin: string;
  english: string;
  example: {
    chinese: string;
    pinyin: string;
    english: string;
  };
  category: string;
  difficulty: 1 | 2 | 3 | 4 | 5 | 6; // HSK levels
  lastReviewed?: number;
  nextReview?: number;
  successRate: number;
  reviewCount: number;
}

export interface Category {
  id: string;
  name: string;
  description: string;
  imageUrl: string;
  cardCount: number;
  difficulty: 1 | 2 | 3 | 4 | 5 | 6;
}

export interface UserProgress {
  streak: number;
  lastStudyDate: number;
  totalStudyTime: number;
  cardsLearned: number;
  cardsReviewed: number;
}