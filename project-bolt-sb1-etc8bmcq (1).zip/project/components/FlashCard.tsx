import React from 'react';
import { StyleSheet, View, Text, Dimensions, Pressable, TouchableOpacity } from 'react-native';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  interpolate,
  useAnimatedGestureHandler,
  runOnJS,
} from 'react-native-reanimated';
import {
  GestureDetector,
  Gesture,
  GestureHandlerRootView,
} from 'react-native-gesture-handler';
import { Flashcard } from '../types/flashcard';
import { CATEGORY_COLORS } from '../data/flashcards';
import { Ionicons } from '@expo/vector-icons';

const { width: SCREEN_WIDTH } = Dimensions.get('window');
const SWIPE_THRESHOLD = SCREEN_WIDTH * 0.3;

interface Props {
  card: Flashcard;
  onSwipe: (direction: 'left' | 'right') => void;
  isFlipped: boolean;
  onFlip: () => void;
  onNext: () => void;
  onPrevious: () => void;
  isFirstCard: boolean;
  isLastCard: boolean;
}

export default function FlashCard({ 
  card, 
  onSwipe, 
  isFlipped, 
  onFlip,
  onNext,
  onPrevious,
  isFirstCard,
  isLastCard 
}: Props) {
  const translateX = useSharedValue(0);

  const cardStyle = useAnimatedStyle(() => {
    const rotate = interpolate(
      translateX.value,
      [-SCREEN_WIDTH / 2, 0, SCREEN_WIDTH / 2],
      ['-10deg', '0deg', '10deg']
    );

    return {
      transform: [
        { translateX: translateX.value },
        { rotate },
      ],
    };
  });

  const panGesture = Gesture.Pan()
    .onUpdate((event) => {
      translateX.value = event.translationX;
    })
    .onEnd((event) => {
      if (Math.abs(event.translationX) > SWIPE_THRESHOLD) {
        const direction = event.translationX > 0 ? 'right' : 'left';
        runOnJS(onSwipe)(direction);
      } else {
        translateX.value = withSpring(0);
      }
    });

  const renderDifficultyStars = () => {
    const stars = [];
    for (let i = 0; i < card.difficulty; i++) {
      stars.push(
        <Ionicons key={i} name="star" size={16} color="#FFD700" />
      );
    }
    return <View style={styles.difficultyStars}>{stars}</View>;
  };

  return (
    <GestureHandlerRootView style={styles.container}>
      <GestureDetector gesture={panGesture}>
        <Animated.View style={[
          styles.card,
          cardStyle,
          { borderTopColor: CATEGORY_COLORS[card.category] }
        ]}>
          <Pressable onPress={onFlip} style={styles.content}>
            {!isFlipped ? (
              <View style={styles.frontSide}>
                <View style={styles.categoryBadge}>
                  <Text style={styles.categoryText}>{card.category}</Text>
                </View>
                {renderDifficultyStars()}
                <Text style={styles.character}>{card.character}</Text>
                <Text style={styles.tapHint}>Tap to see pronunciation and meaning</Text>
              </View>
            ) : (
              <View style={styles.back}>
                <Text style={styles.pinyin}>{card.pinyin}</Text>
                <Text style={styles.english}>{card.english}</Text>
                <View style={styles.example}>
                  <Text style={styles.exampleChinese}>
                    {card.example.chinese}
                  </Text>
                  <Text style={styles.examplePinyin}>
                    {card.example.pinyin}
                  </Text>
                  <Text style={styles.exampleEnglish}>
                    {card.example.english}
                  </Text>
                </View>
              </View>
            )}
          </Pressable>

          <View style={styles.navigationControls}>
            <TouchableOpacity
              style={[styles.navButton, isFirstCard && styles.navButtonDisabled]}
              onPress={onPrevious}
              disabled={isFirstCard}>
              <Ionicons 
                name="chevron-back" 
                size={24} 
                color={isFirstCard ? '#ccc' : '#4A90E2'} 
              />
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.navButton, isLastCard && styles.navButtonDisabled]}
              onPress={onNext}
              disabled={isLastCard}>
              <Ionicons 
                name="chevron-forward" 
                size={24} 
                color={isLastCard ? '#ccc' : '#4A90E2'} 
              />
            </TouchableOpacity>
          </View>
        </Animated.View>
      </GestureDetector>
    </GestureHandlerRootView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  card: {
    width: SCREEN_WIDTH * 0.9,
    height: SCREEN_WIDTH * 1.2,
    backgroundColor: 'white',
    borderRadius: 20,
    borderTopWidth: 4,
    elevation: 5,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    position: 'relative',
  },
  navigationControls: {
    position: 'absolute',
    bottom: 20,
    left: 0,
    right: 0,
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 40,
    zIndex: 1,
  },
  navButton: {
    width: 50,
    height: 50,
    backgroundColor: 'white',
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  navButtonDisabled: {
    opacity: 0.5,
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    paddingBottom: 80, // Add padding to account for navigation controls
  },
  frontSide: {
    alignItems: 'center',
    width: '100%',
  },
  categoryBadge: {
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 12,
    backgroundColor: '#f0f0f0',
    marginBottom: 10,
  },
  categoryText: {
    fontSize: 14,
    color: '#666',
    textTransform: 'capitalize',
  },
  difficultyStars: {
    flexDirection: 'row',
    marginBottom: 15,
  },
  character: {
    fontSize: 72,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 20,
  },
  tapHint: {
    fontSize: 14,
    color: '#999',
    marginTop: 10,
  },
  back: {
    alignItems: 'center',
    width: '100%',
  },
  pinyin: {
    fontSize: 32,
    color: '#4A90E2',
    marginBottom: 15,
  },
  english: {
    fontSize: 28,
    color: '#333',
    marginBottom: 30,
    textAlign: 'center',
  },
  example: {
    width: '100%',
    padding: 20,
    backgroundColor: '#f8f9fa',
    borderRadius: 10,
  },
  exampleChinese: {
    fontSize: 18,
    color: '#333',
    marginBottom: 5,
  },
  examplePinyin: {
    fontSize: 16,
    color: '#666',
    marginBottom: 5,
  },
  exampleEnglish: {
    fontSize: 16,
    color: '#666',
  },
});